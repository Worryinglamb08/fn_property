ESX = nil
local ownedProperties = {}
local blips = {}

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
    end
end)

RegisterNetEvent("fn_property:clientStart")
AddEventHandler("fn_property:clientStart", function(data)
    ownedProperties = data
end)

function ownsProperty(p)
    for k,v in ipairs(Config.properties) do if v==p then return true end end
    return false
end

function _d(a,b) return (a~=nil and a~="" and a~={}) and a or b end

function OpenPropertyMenu(property)
    local elems = {}
    if not ownsProperty(property) then
        table.insert(elems,{title='Buy for <span style="color:green;">$'..tostring(_d(property.price,"N/A")).."</span>",value="buy"})
    else

    end
    table.insert(elems,{title="Exit",value="exit"})
    ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'property_menu',
    {
        title = _d(property.name,"N/A"),
        align = "bottom-right",
        elements = elems
    }
end

Citizen.CreateThread(function()
    for k,v in ipairs(Config.properties) do
        if Config.blip~=nil and Config.blip~={} then
            local blip = AddBlipForCoord(Config.blip.pos)
            SetBlipDisplay(blip,6)
            SetBlipSprite(blip, _d(Config.blip.type,40))
            SetBlipColour(blip, _d(Config.blip.color,29))
        end
    end
    while true do
        Citizen.Wait(0)
        local ped = GetPlayerPed(-1)
        for k,v in ipairs(Config.properties) do
            if v.enter~=nil and v.enter~={} and GetDistanceBetweenCoords(GetEntityCoords(ped), v.enter.pos, false)<15.0 then
                DrawMarker(_d(Config.points.enter.type,1), v.enter.pos, 0, 0, 0, 0, 0, 0, Config.points.enter.size.x, Config.points.enter.size.y, Config.points.enter.size.z, Config.points.enter.color.r, Config.points.enter.color.g, Config.points.enter.color.b, Config.points.enter.color.a, false, false, 0, 0, nil, nil, false)
                if GetDistanceBetweenCoords(GetEntityCoords(ped), v.enter.pos, false)<Config.points.enter.size.x then
                    ESX.ShowHelpNotification(Config.points.enter.helpnoti)
                    if IsControlJustPressed(0, 51) then
                        Config.points.enter.customfunc(v)
                    end
                end
            end
            if v.exit~=nil and v.exit~={} and GetDistanceBetweenCoords(GetEntityCoords(ped), v.exit.pos, false)<15.0 then
                DrawMarker(_d(Config.points.exit.type,1), v.exit.pos, 0, 0, 0, 0, 0, 0, Config.points.exit.size.x, Config.points.exit.size.y, Config.points.exit.size.z, Config.points.exit.color.r, Config.points.exit.color.g, Config.points.exit.color.b, Config.points.exit.color.a, false, false, 0, 0, nil, nil, false)
                if GetDistanceBetweenCoords(GetEntityCoords(ped), v.exit.pos, false)<Config.points.exit.size.x then
                    ESX.ShowHelpNotification(Config.points.exit.helpnoti)
                    if IsControlJustPressed(0, 51) then
                        Config.points.exit.customfunc(v)
                    end
                end
            end
        end
    end
end)