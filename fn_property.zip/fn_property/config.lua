Config = {}
Config.blip = { -- blip to show for each apartment, remove or set to {} to disable
    pos = vector3(-774.0323, 311.0878, 85.69814),
    type = 40,
    color = 29
}
Config.points = {
    enter = {
        size = vector3(1,1,0.2),
        color = {r = 0, g = 0, b = 255, a = 150},
        type = 1,
        helpnoti = "Hit ~INPUT_CONTEXT~ to open apartment menu.",
        customfunc = function(property) -- gets called when E is pressed in the point
            -- print(property.name)
        end
    },
    exit = {
        size = vector3(1,1,0.2),
        color = {r = 255, g = 0, b = 0, a = 150},
        type = 1,
        helpnoti = "Hit ~INPUT_CONTEXT~ to open apartment menu.",
        customfunc = function(property) -- gets called when E is pressed in the point
            -- print(property.name)
        end
    }
}
Config.properties = {
    {
        name = "Modern Apartment 1",
        price = 1000000,
        enter = {
            pos = vector3(-774.0323, 311.0878, 85.69814),
            dest = vector3(-786.8663, 315.7642, 217.6385)
        },
        exit = {
            pos = vector3(),
            dest = vector3()
        },
    }
}